/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'axes\'">' + entity + '</span>' + html;
	}
	var icons = {
		'fa-keyboard_arrow_down': '&#xe313;',
		'fa-keyboard_arrow_left': '&#xe314;',
		'fa-keyboard_arrow_right': '&#xe315;',
		'fa-keyboard_arrow_up': '&#xe316;',
		'fa-local_cafe': '&#xe541;',
		'fa-local_offer': '&#xe54e;',
		'fa-local_post_office': '&#xe554;',
		'fa-keyboard_control': '&#xe5d3;',
		'fa-more_vert': '&#xe5d4;',
		'fa-refresh': '&#xe5d5;',
		'fa-touch_app': '&#xe913;',
		'fa-eye': '&#xe000;',
		'fa-paper-clip': '&#xe001;',
		'fa-mail': '&#xe002;',
		'fa-link': '&#xe005;',
		'fa-ribbon': '&#xe009;',
		'fa-image': '&#xe010;',
		'fa-heart': '&#xe024;',
		'fa-reply': '&#xe039;',
		'fa-circle-plus': '&#xe040;',
		'fa-circle-minus': '&#xe041;',
		'fa-circle-check': '&#xe042;',
		'fa-circle-cross': '&#xe043;',
		'fa-record': '&#xe049;',
		'fa-repeat': '&#xe058;',
		'fa-cloud': '&#xe065;',
		'fa-download': '&#xe069;',
		'fa-location': '&#xe070;',
		'fa-head': '&#xe074;',
		'fa-speech-bubble': '&#xe076;',
		'fa-globe': '&#xe078;',
		'fa-reload': '&#xe080;',
		'fa-share': '&#xe081;',
		'fa-arrow-left': '&#xe094;',
		'fa-arrow-right': '&#xe095;',
		'fa-loader': '&#xe105;',
		'fa-ban': '&#xe107;',
		'fa-flag': '&#xe108;',
		'fa-plus': '&#xe114;',
		'fa-minus': '&#xe115;',
		'fa-check': '&#xe116;',
		'fa-cross': '&#xe117;',
		'fa-menu': '&#xe120;',
		'fa-inbox': '&#xe122;',
		'fa-signal': '&#xf012;',
		'fa-cog': '&#xf013;',
		'fa-gear': '&#xf013;',
		'fa-home': '&#xf015;',
		'fa-flag2': '&#xf024;',
		'fa-star': '&#xf005;',
		'fa-star-o': '&#xf006;',
		'fa-twitter': '&#xf099;',
		'fa-github': '&#xf09b;',
		'fa-thumbs-up': '&#xf164;',
		'fa-thumbs-down': '&#xf165;',
		'fa-stack-overflow': '&#xf16c;',
		'fa-tumblr': '&#xf173;',
		'fa-apple': '&#xf179;',
		'fa-windows': '&#xf17a;',
		'fa-android': '&#xf17b;',
		'fa-weibo': '&#xf18a;',
		'fa-google': '&#xf1a0;',
		'fa-paw': '&#xf1b0;',
		'fa-git': '&#xf1d3;',
		'fa-tencent-weibo': '&#xf1d5;',
		'fa-qq': '&#xf1d6;',
		'fa-wechat': '&#xf1d7;',
		'fa-weixin': '&#xf1d7;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/fa-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
